$(document).ready(function(){
        var msg = $("#msg");
        var log = $("#log");
        var timestamp = 0;

        $("#name").focus();

        // handling user log in 
        $("#login").click(function() {
            // access user name
            var name = $("#name").val();
            // verify whether user name is empty
            if (!name) {
                alert("Please enter a name!");
                return false;
            };

            //write your code here
            //check whether the username contain illegal characters `~!@#$^&*()=|{}':;',\\[\\].<>/?~！@#￥……&*（）——|{}【】‘；：”“'。，、？    
            

            // send request to login.php, write the user name into the cookie
            $.ajax({
                url: 'login.php',
                type: 'POST',
                dataType: 'json',
                data: {name: name},
                success: function() {
                    $(".login").hide();
                }
            })

            return false;
            // complete login process
        });

        
        // send chat message to add_message.php
        $("#form").submit(function() {
            // if no new message, then dont send
            if (!msg.val()) {
                return false;
            }


            // if there's new mesage, send it to add_message.php 
            $.ajax({
                url: 'add_message.php',
                type: 'POST',
                dataType: 'json',
                data: {message: msg.val()},
            })
            
            // Then reset the variable msg to empty string
            msg.val("");

            return false
            
        });



        // keep excuting function updateMsg(), constantly check whether the content in server.php changed
        window.setInterval(function () {
            updateMsg();
        }, 300);

         // update the chatting area. Requst the server.php to fetch the chat log,then add to the chatting area
        function updateMsg() {
            $.post('server.php', {datasize: '1024'}, function(xml) {
                addMessages(xml);
            });
        };



        // passing information to chatting area for displaying. 
        function addMessages(xml) {
           
            var json = eval('('+xml+')');

            // chat log is an array. traversal this array.
            $.each(json, function(i, v) {
                
                // time stamp of each chat log
                tt = parseInt(v.time);

                // only add the current message to the chatting area 
                   if (tt > timestamp) {
                    console.log(v.message);
                    appendLog($("<div/>").text('[' + v.username + ']' + v.message));
                    timestamp = tt
                };
            });
        };

        // translate text of each log to html element in the chatting area. Display the text of message in the chatting area
        function appendLog(msg) {
            var d = log[0]
            var doScroll = d.scrollTop == d.scrollHeight - d.clientHeight;
            msg.appendTo(log)
            if (doScroll) {
                d.scrollTop = d.scrollHeight - d.clientHeight;
            }
        }



    });

    