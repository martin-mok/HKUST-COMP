% This example shows and compares 
% two functions: mean and mymean.
x = 1:10;
mean(x)
mymean(x)
